# Personal Trainer

Personal Trainer built using Angular6 and TypeScript

## Install

Clone this repository and execute in your favorite shell:

* `npm i -g angular-cli` to install `angular-cli` (if you don't have it installed already)
* `npm install` to install local npm dependencies

## Play

After completing installation type in your favorite shell:

* `npm start` to start the app in a new browser window. App files are observed and will be re-transpiled on each change.